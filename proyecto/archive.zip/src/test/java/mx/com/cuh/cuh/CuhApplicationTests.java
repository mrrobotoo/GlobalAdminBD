package mx.com.cuh.cuh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CuhApplicationTests {

	@Test
	void contextLoads() {
	}

}

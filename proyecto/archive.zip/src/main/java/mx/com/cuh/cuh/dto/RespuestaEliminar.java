package mx.com.cuh.cuh.dto;

public class RespuestaEliminar {

}

package mx.com.cuh.global;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CuhApplication {

	public static void main(String[] args) {
		SpringApplication.run(CuhApplication.class, args);
	}

}
